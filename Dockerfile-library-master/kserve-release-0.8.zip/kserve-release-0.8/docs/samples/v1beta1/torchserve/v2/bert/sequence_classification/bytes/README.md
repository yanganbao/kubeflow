To generate input file 

```
python tobytes.py --input_text "this year business is good"
```