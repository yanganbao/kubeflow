# KubeflowOrgV1XGBoostJobSpec

XGBoostJobSpec defines the desired state of XGBoostJob
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**run_policy** | [**V1RunPolicy**](V1RunPolicy.md) |  | 
**xgb_replica_specs** | [**dict(str, V1ReplicaSpec)**](V1ReplicaSpec.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


