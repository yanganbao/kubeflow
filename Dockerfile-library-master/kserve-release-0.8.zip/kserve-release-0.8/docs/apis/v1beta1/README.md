# Inference Service API Reference

Please review the [InferenceService API Reference](https://github.com/kserve/website/blob/main/docs/reference/api.md).