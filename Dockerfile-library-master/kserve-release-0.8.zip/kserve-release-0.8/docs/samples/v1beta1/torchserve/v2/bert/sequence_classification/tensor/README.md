For generating tokenized input run the following command

```
python bert_tokenizer.py --input_text "this year business is good"
```