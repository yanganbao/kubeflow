# Generate tensor input for KServe v2 protocol

The python script converts input file to tensor data

**Steps:**

 1. Check python packages are installed
 2. Run below command
 3. This will write a file `input.json`

```bash
python totensor.py 0.png
```

```bash
python totensor.py sample.txt
```
