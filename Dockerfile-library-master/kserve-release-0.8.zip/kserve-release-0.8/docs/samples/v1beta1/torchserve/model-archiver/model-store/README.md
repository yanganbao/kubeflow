# Model archiver for torchserve

## Place all the file required to grenerate marfile in the model folder