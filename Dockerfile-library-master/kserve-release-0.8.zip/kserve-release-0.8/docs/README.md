# Architecture Overview

Please review KServe [Control Plane](https://github.com/kserve/website/blob/main/docs/modelserving/control_plane.md)
and [Data Plane](https://github.com/kserve/website/blob/main/docs/modelserving/data_plane.md) docs.