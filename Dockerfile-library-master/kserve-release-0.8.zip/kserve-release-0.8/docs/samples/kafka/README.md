Please refer to [kafka example](https://github.com/kserve/website/blob/main/docs/modelserving/kafka/kafka.md)
