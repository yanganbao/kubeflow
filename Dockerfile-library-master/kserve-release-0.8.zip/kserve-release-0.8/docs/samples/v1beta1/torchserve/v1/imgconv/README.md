# Convert image to byteArray

The python script converts image to bytesarray

**Steps:**

 1. Check python packages are installed
 2. Run below command
 3. This will write a file `input.json`

```bash
python img2bytearray.py 0.png
```
